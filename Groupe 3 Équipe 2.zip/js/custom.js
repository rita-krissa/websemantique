document.addEventListener("DOMContentLoaded", function () {
  const header = document.querySelector(".main-header");

  window.addEventListener("scroll", function () {
    if (window.scrollY > 100) {
      header.classList.add("scrolled");
    } else {
      header.classList.remove("scrolled");
    }
  });

  const faqItems = document.querySelectorAll(".faq-item");

  faqItems.forEach((item) => {
    const question = item.querySelector(".faq-question");

    question.addEventListener("click", () => {
      item.classList.toggle("active");

      faqItems.forEach((otherItem) => {
        if (otherItem !== item && otherItem.classList.contains("active")) {
          otherItem.classList.remove("active");
        }
      });
    });
  });
});

const hamburger = document.querySelector(".hamburger");
const mainNav = document.querySelector(".main-nav");
const closeBtn = document.querySelector(".close-btn");
const submenuToggle = document.querySelector(".submenu-toggle");

hamburger.addEventListener("click", () => {
  mainNav.classList.toggle("active");
});

closeBtn.addEventListener("click", () => {
  mainNav.classList.remove("active");
});

if (submenuToggle) {
  submenuToggle.addEventListener("click", (e) => {
    e.preventDefault();
    const parentLi = submenuToggle.closest(".has-submenu");
    parentLi.classList.toggle("active");
  });
}
document.addEventListener("click", (e) => {
  if (!e.target.closest(".has-submenu")) {
    const activeSubmenu = document.querySelector(".has-submenu.active");
    if (activeSubmenu) {
      activeSubmenu.classList.remove("active");
    }
  }
});
