# README - Groupe 3 Équipe 2

## Aperçu du Projet
Ce projet est un site web développé dans le cadre du TD1. Le site a pour objectif de présenter une entreprise fictive spécialisée dans la conception de jardins et l'aménagement paysager. Il permet aux utilisateurs de découvrir les services offerts, de consulter des exemples de réalisations, et de prendre contact avec l'entreprise.

## Choix Techniques
- **Frontend** : HTML, CSS pur et JavaScript ont été utilisés pour développer le site.
- **Bibliothèques** : Nous avons utilisé FontAwesome pour les icônes afin d'améliorer l'expérience utilisateur.
- **Design Responsive** : Le site est entièrement responsive et s'adapte à toutes les tailles d'écran, des smartphones aux ordinateurs de bureau. Tout a été réalisé en CSS pur, sans utiliser de frameworks comme Bootstrap.

## Étapes de Développement
1. **Planification** : Nous avons commencé par créer un wireframe pour visualiser la structure du site et définir les différentes sections.
2. **Design** : Le design a été implémenté en utilisant CSS pur, avec une attention particulière portée à l'expérience utilisateur et à l'accessibilité.
3. **Développement** : Le site a été développé en utilisant HTML pour la structure, CSS pour le style, et JavaScript pour ajouter des fonctionnalités interactives. Les icônes ont été intégrées via FontAwesome.
4. **Tests** : Le site a été testé sur plusieurs appareils (smartphones, tablettes, ordinateurs) et navigateurs (Chrome, Firefox, Safari) pour assurer la compatibilité.
5. **Finalisation** : Des ajustements finaux ont été apportés pour améliorer les performances et l'expérience utilisateur, notamment en optimisant les images et en réduisant le temps de chargement.

## Contributions de l'Équipe
- **Membre 1 ** : Responsable de la conception de la page d'accueil et de l'implémentation de la barre de navigation. Alice a également travaillé sur l'intégration du carrousel d'images.
- **Membre 2 ** : A travaillé sur le formulaire de contact et géré la validation du formulaire en JavaScript. Bob a également implémenté la section des témoignages clients.
- **Membre 3 ** : A créé la mise en page responsive en CSS pur et assuré la compatibilité entre les navigateurs. Charlie a également conçu la page des réalisations.
- **Membre 4 ** : A rédigé le fichier README et géré la documentation du projet. Dana a également contribué à la section des services offerts et a intégré les icônes FontAwesome.

## Défis Rencontrés
- **Défi 1** : La mise en place du design responsive en CSS pur a été un défi, surtout pour gérer les différentes tailles d'écran. Nous avons utilisé des media queries et des unités flexibles (comme `rem` et `%`) pour garantir que le site soit bien affiché sur tous les appareils.
- **Défi 2** : La gestion des sous-menus dans la barre de navigation a posé des problèmes, notamment pour assurer une animation fluide et une bonne accessibilité. Nous avons utilisé JavaScript pour gérer l'ouverture et la fermeture des sous-menus de manière intuitive.
- **Défi 3** : L'intégration d'une carte interactive (via Google Maps ou une alternative) a nécessité des ajustements pour s'assurer qu'elle s'adapte correctement à la mise en page et qu'elle reste fonctionnelle sur tous les appareils. Nous avons également dû gérer les performances pour éviter un temps de chargement trop long.

## Conclusion
Ce projet a été une excellente expérience d'apprentissage pour notre équipe. Nous avons réussi à développer un site web fonctionnel et responsive en utilisant uniquement HTML, CSS pur et JavaScript, sans recourir à des frameworks comme Bootstrap. L'utilisation de FontAwesome a permis d'ajouter des icônes modernes et esthétiques. Nous sommes fiers du résultat final et espérons que les utilisateurs apprécieront la navigation fluide et le design attrayant du site.